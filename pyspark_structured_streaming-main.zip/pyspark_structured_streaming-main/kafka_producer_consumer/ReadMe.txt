Python Simulator for exploring PySpark Structured Streaming with Kafka
