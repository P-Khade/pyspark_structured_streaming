Code used in the video tutorial - Introduction to Spark Streaming | PyCharm Setup | PySpark API | Data Making | DM | DataMaking - https://youtu.be/yYwRoDnvrE4

Playlist on YouTube channel "DataMaking" - https://www.youtube.com/playlist?list=PLe1T0uBrDrfOPffOCe1ET61YSSBvoIvJu
