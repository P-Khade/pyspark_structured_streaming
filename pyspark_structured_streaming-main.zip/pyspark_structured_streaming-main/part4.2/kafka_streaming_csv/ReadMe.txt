Spark Structured Streaming Application with Kafka Source | CSV|PySpark API|DataMaking|DM| DataMaking - https://youtu.be/lmQ6h_3O218
